<h5>Komentar</h5>
<?php if(auth()->guard()->check()): ?>
    <form action="<?php echo e(route('comments.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="book_id" value="<?php echo e($books->id); ?>">
        <div class="form-group">
            <textarea name="content" class="form-control" placeholder="Tulis komentar..." required></textarea>
        </div>
        <button class="btn btn-primary btn-sm">Kirim</button>
    </form>
<?php else: ?>
    <p><a href="<?php echo e(route('login')); ?>">Login</a> untuk menulis komentar.</p>
<?php endif; ?>

<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mt-3">
        <div class="card-body">
            <h5><?php echo e($comment->user->name); ?></h5>
            <p><?php echo e($comment->content); ?></p>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\sanbercode\3_class laravel\1_tugas\6_Git\im-sanbercode-laravel-web-dev\Tugas-12\reviewbook\resources\views\comments\create.blade.php ENDPATH**/ ?>