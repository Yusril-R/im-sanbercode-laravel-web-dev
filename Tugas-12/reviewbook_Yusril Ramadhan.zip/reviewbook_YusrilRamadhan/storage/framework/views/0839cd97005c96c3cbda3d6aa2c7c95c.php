<?php $__env->startSection('title'); ?>
    Tambah Profile
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form action="/profile" method="POST">
        <?php echo csrf_field(); ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul></ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="mb-3">
            <label class="form-label">Alamat</label>
            <textarea name="address" id="address" class="form-control" cols="30" rows="10" required></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Usia</label>
            <input type="number" name="age" id="age" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="/profile" class="btn btn-secondary">Batal</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sanbercode\3_class laravel\1_tugas\6_Git\im-sanbercode-laravel-web-dev\Tugas-12\reviewbook\resources\views/profile/create.blade.php ENDPATH**/ ?>