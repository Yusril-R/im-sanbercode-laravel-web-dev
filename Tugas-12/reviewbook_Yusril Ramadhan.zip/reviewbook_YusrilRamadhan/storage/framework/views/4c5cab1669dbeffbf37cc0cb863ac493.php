<?php $__env->startSection('title'); ?>
    Genre
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h2>Tambah Genre Baru</h2>
    <form action="/genre" method="POST">
        <?php echo csrf_field(); ?>

        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul></ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="mb-3">
            <label class="form-label">Nama Genre</label>
            <input type="text" name="name" id="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Deskripsi</label><br>
            <textarea name="description" id="description" class="form-control" cols="30" rows="10"></textarea>
        </div>
        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="/genre" class="btn btn-secondary">Batal</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sanbercode\3_class laravel\1_tugas\6_Git\im-sanbercode-laravel-web-dev\Tugas-12\reviewbook\resources\views/genres/create.blade.php ENDPATH**/ ?>