<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1>SELAMAT DATANG <?php echo e($first_name); ?> <?php echo e($last_name); ?> !</h1>
    <h2>Terima kasih telah bergabung di SanberBook. Social Media kita bersama!</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sanbercode\3_class laravel\1_tugas\6_Git\im-sanbercode-laravel-web-dev\Tugas-12\reviewbook\resources\views\welcome.blade.php ENDPATH**/ ?>