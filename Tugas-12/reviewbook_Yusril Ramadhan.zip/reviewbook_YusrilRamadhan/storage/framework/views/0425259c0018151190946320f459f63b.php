<?php $__env->startSection('title'); ?>
    Profile
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1>Profile</h1>
    <div class="container">
        <p><strong>Nama:</strong> <?php echo e(Auth::user()->name); ?></p>
        <p><strong>Email:</strong> <?php echo e(Auth::user()->email); ?></p>
        <p>Alamat: <?php echo e($profile->address); ?></p>
        <p>Usia : <?php echo e($profile->age); ?></p>
        <a href="/profile/<?php echo e($profile->id); ?>/edit" class="btn btn-warning">Edit</a>
        <a href="/profile/create" class="btn btn-primary">Buat Profile</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sanbercode\3_class laravel\1_tugas\6_Git\im-sanbercode-laravel-web-dev\Tugas-12\reviewbook\resources\views/profile/index.blade.php ENDPATH**/ ?>