<style>
    .navmenu {
        padding: 15px;
        font-size: 18px
    }
    .navmenu a.active {
        color: #00b56a !important;
        font-weight: bold;
        text-decoration: underline;
    }

    .navmenu a.inactive {
        color: #333;
        font-weight: normal;
        text-decoration: none;
    }
</style>
<header id="header" class="header d-flex align-items-center sticky-top" <div
    class="container position-relative d-flex align-items-center">

    <a href="/" class="logo d-flex align-items-center me-auto px-2">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1 class="sitename ">RevBooks</h1><span>.</span>
    </a>

    <nav id="navmenu" class="navmenu">
        <ul>
            <li><a href="/" class="<?php echo e(Request::is('/') ? 'active' : 'inactive'); ?>">Home</a></li>
            <li><a href="/book" class="<?php echo e(Request::is('book*') ? 'active' : 'inactive'); ?>">Book</a></li>
            <li><a href="/genre" class="<?php echo e(Request::is('genre*') ? 'active' : 'inactive'); ?>">Genre</a></li>
            <?php if(auth()->guard()->guest()): ?>
                <li><a href="/login" class="<?php echo e(Request::is('login') ? 'active' : 'inactive'); ?>">Login</a></li>
                <li><a href="/register" class="<?php echo e(Request::is('register') ? 'active' : 'inactive'); ?>">Register</a></li>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <form action="/logout" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="d-flex ">
                        <li class="dropdown cursor-pointer"><i
                                class="fa-solid fa-user ">&nbsp;&nbsp;<?php echo e(Auth::user()->name); ?></i>
                            <ul>
                                <li><a href="/profile" class="">Profile</a></li>
                                <li><button class="btn btn-danger">Logout</button></li>
                            </ul>
                        </li>
                    </div>
                </form>
            <?php endif; ?>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
    </nav>

    </div>
</header>
<?php /**PATH C:\laragon\www\sanbercode\3_class laravel\1_tugas\6_Git\im-sanbercode-laravel-web-dev\Tugas-12\reviewbook\resources\views/partials/navbar.blade.php ENDPATH**/ ?>