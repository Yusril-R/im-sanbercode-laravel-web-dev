<?php $__env->startSection('title'); ?>
    Edit Profile
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form action="/profile/<?php echo e($profile->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label class="form-label">Alamat</label>
            <textarea name="address" id="address" class="form-control" cols="30" rows="10" required><?php echo e($profile->address); ?></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Usia</label>
            <input type="number" name="age" id="age" class="form-control" value="<?php echo e($profile->age); ?>" required>
        </div>
        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="/profile" class="btn btn-secondary">Batal</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sanbercode\3_class laravel\1_tugas\6_Git\im-sanbercode-laravel-web-dev\Tugas-12\reviewbook\resources\views/profile/edit.blade.php ENDPATH**/ ?>