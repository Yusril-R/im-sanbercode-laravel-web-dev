<?php $__env->startSection('title'); ?>
    
    Genre
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>List Genre</h2>
        <a href="/genre/create" class="btn btn-primary mb-3">Tambah Genre</a>
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>Nama Genre</th>
                    <th>Deskripsi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($genre->name); ?></td>
                        <td><?php echo e($genre->description); ?></td>
                        <td>
                            <form action="/genre/<?php echo e($genre->id); ?>" method="POST">
                                <a href="/genre/<?php echo e($genre->id); ?>" class="btn btn-info btn-sm">Detail</a>
                                <a href="/genre/<?php echo e($genre->id); ?>/edit" class="btn btn-warning btn-sm">Edit</a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm mt-2">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sanbercode\3_class laravel\1_tugas\6_Git\im-sanbercode-laravel-web-dev\Tugas-12\reviewbook\resources\views/genres/index.blade.php ENDPATH**/ ?>