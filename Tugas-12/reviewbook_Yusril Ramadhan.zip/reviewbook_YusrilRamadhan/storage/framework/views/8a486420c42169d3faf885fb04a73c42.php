<?php $__env->startSection('title'); ?>
    Detail Buku
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Judul: <?php echo e($books->title); ?></h5>
            <img src="<?php echo e(asset('storage/' . $books->image)); ?>" class="image-fluid" alt="Gambar buku">
            <p class="card-text">Genre: <?php echo e($books->genre->name); ?></p>
            <p class="card-text">Deskripsi: <?php echo e($books->summary); ?></p>
            <p class="card-text">Stok: <?php echo e($books->stok); ?></p>
            <a href="/book" class="btn btn-secondary mt-3">Kembali</a>
        </div>
    </div>

    <div class="mt-3">
        <?php echo $__env->make('comments.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sanbercode\3_class laravel\1_tugas\6_Git\im-sanbercode-laravel-web-dev\Tugas-12\reviewbook\resources\views/books/show.blade.php ENDPATH**/ ?>