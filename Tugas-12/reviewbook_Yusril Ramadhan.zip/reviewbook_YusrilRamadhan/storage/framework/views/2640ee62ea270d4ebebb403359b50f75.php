<?php $__env->startSection('title'); ?>
    Detail Genre
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Nama: <?php echo e($genres->name); ?></h5>
            <p class="card-text">Deskripsi: <?php echo e($genres->description); ?></p>
            <a href="/genre" class="btn btn-secondary mt-3">Kembali</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sanbercode\3_class laravel\1_tugas\6_Git\im-sanbercode-laravel-web-dev\Tugas-12\reviewbook\resources\views\genres\show.blade.php ENDPATH**/ ?>